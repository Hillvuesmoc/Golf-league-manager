# Golf League Team Manager

A single-commissioner web app for running a 9-hole scramble league: track players and skill
ratings, check off who's playing each week, generate balanced teams, edit them by hand, and
copy the result into GroupMe.

There are no player accounts. Only you log in. Players still sign up through GroupMe like
always — you just check the matching boxes in this app.

---

## 1. Create a Firebase project (free tier is plenty)

1. Go to https://console.firebase.google.com and click **Add project**. Name it anything
   (e.g. "golf-league").
2. Once created, click the **web icon (`</>`)** to register a web app. Name it anything and
   skip Firebase Hosting (you'll use Netlify instead).
3. Firebase will show you a `firebaseConfig` object with keys like `apiKey`, `authDomain`,
   etc. Keep this tab open — you'll need these values in step 3.

### Turn on Firestore (the database)
1. In the left sidebar: **Build → Firestore Database → Create database**.
2. Choose **Start in production mode**, pick any region close to you, click **Enable**.
3. Go to the **Rules** tab and replace the contents with what's in `firestore.rules` in this
   project, then click **Publish**. This makes sure only your logged-in account can read or
   write your league data.

### Turn on Authentication (just for you)
1. **Build → Authentication → Get started**.
2. Under **Sign-in method**, enable **Email/Password**.
3. Go to the **Users** tab → **Add user**. Enter the email and password *you* want to log in
   with. This is the only account that will ever exist — there's no public sign-up page.

---

## 2. Configure the project

1. Copy `.env.example` to a new file named `.env`.
2. Fill in the values from the `firebaseConfig` object you saw in step 1:

   ```
   VITE_FIREBASE_API_KEY=...
   VITE_FIREBASE_AUTH_DOMAIN=...
   VITE_FIREBASE_PROJECT_ID=...
   VITE_FIREBASE_STORAGE_BUCKET=...
   VITE_FIREBASE_MESSAGING_SENDER_ID=...
   VITE_FIREBASE_APP_ID=...
   ```

   `.env` is already in `.gitignore` so it never gets committed or pushed publicly.

---

## 3. Try it locally (optional but recommended)

```
npm install
npm run dev
```

Open the printed `localhost` URL, log in with the email/password you created above, and try
adding a player or two.

---

## 4. Push to GitHub

```
git init
git add .
git commit -m "Initial commit"
```

Create a new empty repository on GitHub (no README/license, you already have files), then:

```
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

---

## 5. Deploy on Netlify

1. In Netlify: **Add new site → Import an existing project → GitHub**, pick your repo.
2. Build settings should auto-detect from `netlify.toml`:
   - Build command: `npm run build`
   - Publish directory: `dist`
3. Before deploying, add your environment variables: **Site settings → Environment
   variables**, and add the same six `VITE_FIREBASE_...` keys from your `.env` file.
4. Click **Deploy site**. Netlify will give you a URL like `yourname-golf.netlify.app` —
   that's your permanent link. You can bookmark it or add it to your phone's home screen.

Any time you want to change the app later, edit the code, commit, and push — Netlify
rebuilds and redeploys automatically.

---

## How it works day to day

1. Players call out their availability in GroupMe during the week, as usual.
2. You open the app, go to the Monday or Tuesday tab, and check off who's playing.
3. Hit **Generate Teams**. Review, drag players between teams, or lock a team you like and
   regenerate the rest.
4. Hit **Publish Teams**, then **Copy for GroupMe** and paste the result into your group chat.

Your roster, ratings, and pairing history are stored in Firestore and stay there
permanently — nothing resets when you close the tab or switch devices.
